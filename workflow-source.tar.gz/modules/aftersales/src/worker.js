import { objectBucket } from "../../cloud-storage";
import { sharedDatabase } from '../../database';
import { workspace, core, requireEntity } from '../../bridge';
const json=(body,status=200)=>Response.json(body,{status});
const safeName=name=>name.replace(/[^a-zA-Z0-9._-]/g,'_');
export default {
 async fetch(request,env){
  try{
   const url=new URL(request.url),path=url.pathname;
   const session=await workspace(request,env,'aftersales');
   if(!session)return path.startsWith('/api/')?json({error:'请先登录 Workplace 并确认售后权限'},401):new Response('<p>请从 <a href="http://127.0.0.1:8975" target="_top">Workplace 总入口</a>登录。</p>',{status:401,headers:{'Content-Type':'text/html; charset=utf-8'}});
   const db=sharedDatabase(env),user=session.user;
   if(path==='/api/auth/session')return json({authenticated:true,username:user.name,role:user.role});
   if(path.startsWith('/api/auth/'))return json({error:'请在 Workplace 统一管理账号'},403);
   if(path==='/api/state'&&request.method==='GET'){
    const result=await core(request,env,'/api/service-state');
    if(!result.ok)return result;return json({data:await result.json()});
   }
   if(path.startsWith('/api/')&&request.method!=='GET'&&user.role!=='aftersales')return json({error:'当前岗位只能查看售后资料'},403);
   if(path==='/api/state'&&request.method==='PUT')return core(request,env,'/api/action/service-save','POST',await request.json());
   if(path.startsWith('/api/action/')&&request.method==='POST'){
    const action=path.split('/').pop();
    if(!['stock-reserve','service-request','service-part'].includes(action))return json({error:'操作不存在'},404);
    return core(request,env,path,'POST',await request.json());
   }
   if(path==='/api/attachments'&&request.method==='GET'){
    const denied=await requireEntity(request,env,'service_tickets',url.searchParams.get('ticketId')||'');if(denied)return denied;
    const {results}=await db.prepare("SELECT * FROM shared_attachments WHERE entity_type='service' AND entity_id=? ORDER BY created_at DESC").bind(url.searchParams.get('ticketId')).all();
    return json(results.map(a=>({id:a.id,ticketId:a.entity_id,name:a.file_name,type:a.content_type,size:a.size,createdAt:a.created_at,url:`/api/attachments/${a.id}`})));
   }
   if(path==='/api/attachments'&&request.method==='POST'){
    const form=await request.formData(),ticketId=String(form.get('ticketId')||''),file=form.get('file');
    const denied=await requireEntity(request,env,'service_tickets',ticketId);if(denied)return denied;
    if(!(file instanceof File)||file.size>25*1024*1024)return json({error:'附件须小于 25 MB'},400);
    if(!await db.prepare('SELECT id FROM service_tickets WHERE id=?').bind(ticketId).first())return json({error:'请先保存售后单'},409);
    const id=crypto.randomUUID(),key=`service/${ticketId}/${id}`,stamp=new Date().toISOString();
    await objectBucket(env.ATTACHMENTS, env, "aftersales").put(key,file.stream(),{httpMetadata:{contentType:file.type||'application/octet-stream'}});
    try {await db.batch([
     db.prepare("INSERT INTO shared_attachments VALUES(?,'service',?,?,?,?,?,?,?)").bind(id,ticketId,file.name,file.type||'application/octet-stream',file.size,key,user.id,stamp),
     db.prepare("INSERT INTO audit_events VALUES(?,'attachment',?,'上传售后附件',?,?,?,?)").bind(crypto.randomUUID(),id,user.id,user.name,JSON.stringify({ticketId,fileName:file.name}),stamp)
    ]);}catch(e){await objectBucket(env.ATTACHMENTS, env, "aftersales").delete(key);throw e;}
    return json({id,ticketId,name:file.name,type:file.type,size:file.size,url:`/api/attachments/${id}`},201);
   }
   const match=path.match(/^\/api\/attachments\/([^/]+)$/);
   if(match){
    const a=await db.prepare("SELECT * FROM shared_attachments WHERE id=? AND entity_type='service'").bind(match[1]).first();
    if(!a)return json({error:'附件不存在'},404);
    const denied=await requireEntity(request,env,'service_tickets',a.entity_id);if(denied)return denied;
    if(request.method==='GET'){
     const object=await objectBucket(env.ATTACHMENTS, env, "aftersales").get(a.object_key);if(!object)return json({error:'附件文件不存在'},404);
     const inline=/^image\/(png|jpeg|webp|gif)$/.test(a.content_type);
     return new Response(object.body,{headers:{'Content-Type':a.content_type,'Content-Disposition':`${inline?'inline':'attachment'}; filename="${safeName(a.file_name)}"`,'X-Content-Type-Options':'nosniff','Cache-Control':'private, no-store'}});
    }
    if(request.method==='DELETE'){
     await db.batch([db.prepare("UPDATE shared_attachments SET entity_type='service_removed' WHERE id=?").bind(a.id),db.prepare("INSERT INTO audit_events VALUES(?,'attachment',?,'移出售后附件列表',?,?,?,?)").bind(crypto.randomUUID(),a.id,user.id,user.name,JSON.stringify({ticketId:a.entity_id}),new Date().toISOString())]);return json({ok:true});
    }
   }
   if(path.startsWith('/api/'))return json({error:'接口不存在'},404);
   return env.ASSETS.fetch(request);
  }catch(e){console.error(e);return json({error:'未能完成操作，请保留当前修改并重试'},500);}
 }
};
