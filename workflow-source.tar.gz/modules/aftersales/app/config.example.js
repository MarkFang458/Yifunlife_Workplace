// Cloudflare Worker 与网页在同一域名时，apiBase 保持空白即可。
window.AFTER_SALES_CONFIG = {
  enabled: true,
  apiBase: "",
};
