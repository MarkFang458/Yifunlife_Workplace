import { env } from "cloudflare:workers";
import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";
import { sharedDatabase } from "../../database";
export function getDb() { return drizzle(sharedDatabase(env) as any, { schema }); }
