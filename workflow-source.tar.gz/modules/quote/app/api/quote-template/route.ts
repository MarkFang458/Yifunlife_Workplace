import { objectBucket } from '../../../../cloud-storage';
import { env } from "cloudflare:workers";
import { getLoginSession } from "../../../lib/auth";

export async function GET(request: Request) {
  const session = await getLoginSession(request);
  if (!session) return Response.json({ error: "请先登录" }, { status: 401 });
  const id = new URL(request.url).searchParams.get("id") || "";
  if (!/^[a-f0-9-]{36}$/.test(id)) return new Response("Not found", { status: 404 });
  const object = await objectBucket(env.PRODUCT_IMAGES, env, "quote").get(`quote-templates/${id}`);
  if (!object || (object.customMetadata?.owner !== session.email && !["admin", "management", "ceo"].includes(session.role)))
    return new Response("Not found", { status: 404 });
  return new Response(object.body as unknown as ReadableStream<Uint8Array>, { headers: { "Content-Type": "application/octet-stream", "Cache-Control": "private, no-store" } });
}

export async function POST(request: Request) {
  const session = await getLoginSession(request);
  if (!session) return Response.json({ error: "请先登录" }, { status: 401 });
  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File) || !/\.xlsx$/i.test(file.name))
    return Response.json({ error: "请使用 XLSX 格式保留原始报价模板" }, { status: 400 });
  if (file.size > 30 * 1024 * 1024)
    return Response.json({ error: "原始报价模板不能超过 30MB" }, { status: 413 });
  const id = crypto.randomUUID();
  await objectBucket(env.PRODUCT_IMAGES, env, "quote").put(`quote-templates/${id}`, await file.arrayBuffer(), {
    httpMetadata: { contentType: "application/octet-stream" },
    customMetadata: { owner: session.email },
  });
  return Response.json({ id }, { status: 201 });
}
