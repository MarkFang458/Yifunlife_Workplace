import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  basePath: process.env.YIFUN_MODULE_BASE || "",
};

export default nextConfig;
