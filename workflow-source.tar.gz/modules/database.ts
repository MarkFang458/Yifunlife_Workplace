// One database owned by the local Workplace service. No module has a second business database.
export function sharedDatabase(env: any): any {
  // Cloudflare deployments share ONE D1 database binding across all modules.
  // Desktop development continues using the transactional SQLite bridge.
  if (env.DATABASE_BACKEND === 'd1') {
    if (!env.BUSINESS_DB) throw new Error('BUSINESS_DB binding is required for D1');
    return env.BUSINESS_DB;
  }
  if (env.DATABASE_BACKEND && env.DATABASE_BACKEND !== 'bridge') {
    throw new Error('Unsupported DATABASE_BACKEND');
  }
  const call = async (statements: any[]) => {
    const response = await fetch(`${env.WORKPLACE_URL || 'http://127.0.0.1:8975'}/internal/database`, {
      method:'POST',headers:{'Content-Type':'application/json','X-Workspace-Bridge':env.WORKSPACE_BRIDGE || ''},
      body:JSON.stringify({statements})
    });
    const result:any = await response.json();
    if (!response.ok) throw new Error(result.error || '共用资料保存失败');
    return result.results;
  };
  const prepare = (sql:string, params:any[] = []):any => ({
    sql, params,
    bind(...values:any[]) { return prepare(sql, values); },
    async all() { return (await call([{sql,params}]))[0]; },
    async run() { return this.all(); },
    async first(column?:string) { const result = await this.all(); const row=result.results[0]; return row ? (column ? row[column] : row) : null; },
    async raw(options?:{columnNames?:boolean}) { const result=await this.all(); return options?.columnNames ? [result.columns,...result.rows] : result.rows; }
  });
  return {prepare, batch:(statements:any[])=>call(statements.map(({sql,params})=>({sql,params})))};
}
