export function workplaceOrigin(): string {
  return window.location.pathname.startsWith('/modules/') ? window.location.origin : 'http://127.0.0.1:8975';
}
