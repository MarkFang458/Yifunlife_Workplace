"""Build all original module pages without initializing a business database."""
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
assets = {
    'workplace-logo.png': ['modules/quote/public/brand/yifun-life-logo.png', 'modules/procurement/public/yifun-logo.png', 'modules/aftersales/app/assets/yifun-life-logo-transparent.png', 'modules/aftersales/app/assets/yifun-life-logo-standard.png'],
    'workplace-favicon.png': ['modules/quote/public/workplace-favicon.png', 'modules/procurement/public/yifun-mark.png', 'modules/aftersales/app/assets/workplace-favicon.png'],
    'workplace-theme.css': ['modules/aftersales/app/workplace-theme.css']
}
for source, targets in assets.items():
    for target in targets:
        (ROOT / target).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / source, ROOT / target)
for name, executable in [('quote', 'vinext'), ('procurement', 'vite')]:
    subprocess.run(['./node_modules/.bin/' + executable, 'build'], cwd=ROOT / 'modules' / name,
                   env={**os.environ, 'YIFUN_MODULE_BASE': '/modules/' + name, 'WRANGLER_SEND_METRICS': 'false'}, check=True)
