"""Export schema from a NEW empty database, never from business data."""
import os, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as folder:
    env = {**os.environ, 'YIFUN_DATA_ROOT': folder, 'YIFUN_DB': str(Path(folder)/'schema.sqlite3')}
    code = "import database,sqlite3;database.init();db=database.connect();print(chr(10).join(r[0]+';' for r in db.execute(\"SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 WHEN 'view' THEN 2 ELSE 3 END,rowid\")))"
    schema = subprocess.check_output([sys.executable, '-c', code], cwd=ROOT, env=env, text=True)
    target = ROOT/'cloudflare'/'migrations'/'0001_full_schema.sql'
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists(): raise SystemExit('Existing migration is immutable; create a new migration instead.')
    target.write_text('-- Schema only. No customers, passwords, orders or images.\n'+schema)
    print(target)
