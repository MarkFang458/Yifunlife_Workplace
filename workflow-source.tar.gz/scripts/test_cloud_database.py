"""Exercise the cloud SQL adapter against a local, real Durable Object runtime.

Run with NODE and YIFUN_MINIFLARE_MODULE pointing to an installed Node runtime
and Miniflare package. This uses an empty temporary database and no credentials.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import cloud_database


def main():
    module = os.environ['YIFUN_MINIFLARE_MODULE']
    with tempfile.TemporaryDirectory() as directory:
        fixture = Path(directory)
        worker = (ROOT / 'cloudflare/business-database.js').read_text() + "\nexport default {fetch(request,env){return env.BUSINESS.get(env.BUSINESS.idFromName('integration-test')).fetch(request)}};\n"
        runner = fixture / 'worker.cjs'
        runner.write_text('const {Miniflare}=require(' + json.dumps(module) + ');\n'
                          'const mf=new Miniflare({host:"127.0.0.1",port:0,compatibilityDate:"2026-05-15",modules:true,script:'
                          + json.dumps(worker) + ',durableObjects:{BUSINESS:{className:"BusinessDatabase",useSQLite:true}}});\n'
                          '(async()=>console.log((await mf.ready).toString()))();\n'
                          'process.on("SIGTERM",async()=>{await mf.dispose();process.exit(0)});\n')
        process = subprocess.Popen([os.environ.get('NODE', 'node'), str(runner)], stdout=subprocess.PIPE, text=True)
        try:
            endpoint = process.stdout.readline().strip().rstrip('/')
            if not endpoint.startswith('http://127.0.0.1:'):
                raise RuntimeError('Local test service did not start')

            def transport(path, payload=None):
                body = None if payload is None else json.dumps(payload).encode()
                req = urllib.request.Request(endpoint + path, data=body, headers={'Content-Type': 'application/json'})
                try:
                    with urllib.request.urlopen(req, timeout=30) as response:
                        return json.load(response)
                except urllib.error.HTTPError as error:
                    if error.code == 409: raise cloud_database.ConcurrentUpdate('conflict') from None
                    if error.code == 422: raise cloud_database.sqlite3.IntegrityError('constraint') from None
                    raise

            cloud_database.request = transport
            os.environ['YIFUN_DATA_ROOT'] = str(fixture / 'data')
            os.environ['YIFUN_DATABASE_BACKEND'] = 'cloudflare'
            import workplace, database
            workplace.init()
            with database.connect() as db:
                assert db.execute('SELECT COUNT(*) FROM marketing_accounts').fetchone()[0] == 18
                db.execute('CREATE TABLE cloud_test_sequence(id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT UNIQUE)')
                db.execute("INSERT INTO cloud_test_sequence VALUES(100,'deleted')")
                db.execute('DELETE FROM cloud_test_sequence')
            with database.connect() as db:
                assert db.execute("INSERT INTO cloud_test_sequence(label) VALUES('next')").lastrowid == 101
            with database.connect() as db:
                assert db.execute("SELECT id FROM cloud_test_sequence WHERE label='next'").fetchone()[0] == 101
            first, stale = database.connect(), database.connect()
            first.execute("INSERT INTO settings VALUES('cloud-test','a')")
            first.commit()
            stale.execute("INSERT INTO settings VALUES('stale-write','b')")
            try: stale.commit()
            except cloud_database.ConcurrentUpdate: pass
            else: raise AssertionError('Stale transaction committed')
            first.close(); stale.close()
            try:
                with database.connect() as db:
                    db.execute("INSERT INTO settings VALUES('rolled-back','never')")
                    assert db.execute("SELECT value FROM settings WHERE key='rolled-back'").fetchone()[0] == 'never'
                    raise ValueError('rollback fixture')
            except ValueError: pass
            snapshot = transport('/snapshot')
            try:
                transport('/commit', {'revision': snapshot['revision'], 'statements': [
                    {'sql': "INSERT INTO settings VALUES('partial-write','never')", 'params': []},
                    {'sql': "INSERT INTO settings VALUES('cloud-test','duplicate')", 'params': []}]})
            except cloud_database.sqlite3.IntegrityError: pass
            else: raise AssertionError('Invalid batch committed')
            with database.connect() as db:
                for key in ('stale-write', 'rolled-back', 'partial-write'):
                    assert db.execute('SELECT 1 FROM settings WHERE key=?', (key,)).fetchone() is None
            assert not database.DB_PATH.exists()
            print('PASS: original migrations, 18 account identities, remote atomic commit, rollback, revision conflicts, AUTOINCREMENT and no application database file')
        finally:
            process.terminate()
            process.wait(timeout=15)


if __name__ == '__main__':
    main()
