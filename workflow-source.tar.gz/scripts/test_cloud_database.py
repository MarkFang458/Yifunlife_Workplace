"""Exercise the cloud SQL adapter against a local, real Durable Object runtime.

Run with NODE and YIFUN_MINIFLARE_MODULE pointing to an installed Node runtime
and Miniflare package. This uses an empty temporary database and no credentials.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import cloud_database


def main():
    module = os.environ['YIFUN_MINIFLARE_MODULE']
    with tempfile.TemporaryDirectory() as directory:
        fixture = Path(directory)
        worker = (ROOT / 'cloudflare/business-database.js').read_text() + "\nexport default {fetch(request,env){return env.BUSINESS.get(env.BUSINESS.idFromName('integration-test')).fetch(request)}};\n"
        runner = fixture / 'worker.cjs'
        runner.write_text('const {Miniflare}=require(' + json.dumps(module) + ');\n'
                          'const mf=new Miniflare({host:"127.0.0.1",port:0,compatibilityDate:"2026-05-15",modules:true,script:'
                          + json.dumps(worker) + ',durableObjects:{BUSINESS:{className:"BusinessDatabase",useSQLite:true}}});\n'
                          '(async()=>console.log((await mf.ready).toString()))();\n'
                          'process.on("SIGTERM",async()=>{await mf.dispose();process.exit(0)});\n')
        process = subprocess.Popen([os.environ.get('NODE', 'node'), str(runner)], stdout=subprocess.PIPE, text=True)
        try:
            endpoint = process.stdout.readline().strip().rstrip('/')
            if not endpoint.startswith('http://127.0.0.1:'):
                raise RuntimeError('Local test service did not start')

            def transport(path, payload=None):
                body = None if payload is None else json.dumps(payload).encode()
                req = urllib.request.Request(endpoint + path, data=body, headers={'Content-Type': 'application/json'})
                try:
                    with urllib.request.urlopen(req, timeout=30) as response:
                        return json.load(response)
                except urllib.error.HTTPError as error:
                    if error.code == 409: raise cloud_database.ConcurrentUpdate('conflict') from None
                    if error.code == 422: raise cloud_database.sqlite3.IntegrityError('constraint') from None
                    raise

            cloud_database.request = transport
            os.environ['YIFUN_DATA_ROOT'] = str(fixture / 'data')
            os.environ['YIFUN_DATABASE_BACKEND'] = 'cloudflare'
            import workplace, database
            workplace.init()
            with database.connect() as db:
                assert db.execute('SELECT COUNT(*) FROM marketing_accounts').fetchone()[0] == 18
                db.execute('CREATE TABLE cloud_test_sequence(id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT UNIQUE)')
                db.execute("INSERT INTO cloud_test_sequence VALUES(100,'deleted')")
                db.execute('DELETE FROM cloud_test_sequence')
            with database.connect() as db:
                assert db.execute("INSERT INTO cloud_test_sequence(label) VALUES('next')").lastrowid == 101
            with database.connect() as db:
                assert db.execute("SELECT id FROM cloud_test_sequence WHERE label='next'").fetchone()[0] == 101
            first, stale = database.connect(), database.connect()
            first.execute("INSERT INTO settings VALUES('cloud-test','a')")
            first.commit()
            stale.execute("INSERT INTO settings VALUES('stale-write','b')")
            try: stale.commit()
            except cloud_database.ConcurrentUpdate: pass
            else: raise AssertionError('Stale transaction committed')
            first.close(); stale.close()
            try:
                with database.connect() as db:
                    db.execute("INSERT INTO settings VALUES('rolled-back','never')")
                    assert db.execute("SELECT value FROM settings WHERE key='rolled-back'").fetchone()[0] == 'never'
                    raise ValueError('rollback fixture')
            except ValueError: pass
            snapshot = transport('/snapshot')
            try:
                transport('/commit', {'revision':snapshot['revision'],'commit_id':'0'*32,
                                     'snapshot':{'schema':snapshot['schema'],'tables':[]}})
            except cloud_database.sqlite3.IntegrityError: pass
            else: raise AssertionError('Malformed state committed')
            with database.connect() as db:
                db.execute('CREATE TABLE cloud_trigger_source(id TEXT PRIMARY KEY, value INTEGER)')
                db.execute('CREATE TABLE cloud_trigger_result(id TEXT PRIMARY KEY, source_id TEXT REFERENCES cloud_trigger_source(id), created_at TEXT)')
                db.execute("CREATE TRIGGER cloud_random_trigger AFTER INSERT ON cloud_trigger_source BEGIN INSERT INTO cloud_trigger_result VALUES(lower(hex(randomblob(16))),NEW.id,strftime('%Y-%m-%dT%H:%M:%fZ','now')); END")
                db.execute("INSERT INTO cloud_trigger_source VALUES('source',1)")
                generated=tuple(db.execute('SELECT id,created_at FROM cloud_trigger_result').fetchone())
            with database.connect() as db:
                assert tuple(db.execute('SELECT id,created_at FROM cloud_trigger_result').fetchone())==generated
                large=2**60+123
                db.execute('CREATE TABLE cloud_large_integer(value INTEGER)')
                db.execute('INSERT INTO cloud_large_integer VALUES(?)',(large,))
            with database.connect() as db:
                assert db.execute('SELECT value FROM cloud_large_integer').fetchone()[0]==large
            with database.connect() as db:
                for key in ('stale-write', 'rolled-back', 'partial-write'):
                    assert db.execute('SELECT 1 FROM settings WHERE key=?', (key,)).fetchone() is None
            with database.connect() as db:
                text='模拟🙂' * 60000
                db.execute("INSERT INTO settings VALUES('unicode-chunks',?)",(text,))
            with database.connect() as db:
                assert db.execute("SELECT value FROM settings WHERE key='unicode-chunks'").fetchone()[0]==text
                db.execute("DELETE FROM settings WHERE key='unicode-chunks'")
            left,right=database.connect(),database.connect()
            revision=transport('/snapshot')['revision']
            for connection in (left,right):
                connection.execute("INSERT OR IGNORE INTO settings VALUES('cloud-test','ignored')")
                connection.commit()
            assert transport('/snapshot')['revision']==revision
            left.close();right.close()
            os.environ['YIFUN_DEMO_MODE']='1' 
            import secrets, demo_data
            with database.connect() as db:
                actor=dict(workplace.add_employee(db,{'email':'fixture@example.invalid','name':'模拟管理员','password':secrets.token_urlsafe(24)},True))
                demo_data.seed(db,actor)
                item=db.execute('SELECT id FROM order_items LIMIT 1').fetchone()[0]
                db.execute('UPDATE order_items SET received_quantity=1,stocked_by=? WHERE id=?',(actor['id'],item))
                db.execute('UPDATE order_items SET stocked_quantity=1 WHERE id=?',(item,))
                receipt=tuple(db.execute("SELECT id,created_at FROM stock_movements WHERE kind='receipt'").fetchone())
            with database.connect() as db:
                assert tuple(db.execute("SELECT id,created_at FROM stock_movements WHERE kind='receipt'").fetchone())==receipt
                assert db.execute('SELECT COUNT(*) FROM customers').fetchone()[0]==3
                assert not list(db.execute('PRAGMA foreign_key_check'))
            assert not database.DB_PATH.exists()
            print('PASS: original migrations, platform identities, atomic snapshot commit, rollback, revision conflicts, AUTOINCREMENT, generated trigger IDs, timestamps, large integers and no application database file')
        finally:
            process.terminate()
            process.wait(timeout=15)


if __name__ == '__main__':
    main()
