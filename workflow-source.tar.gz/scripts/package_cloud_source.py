"""Package all module sources, excluding runtime data, files and credentials."""
from pathlib import Path
import hashlib
import os
import re
import tarfile

ROOT = Path(__file__).resolve().parents[1]
excluded = {'node_modules', 'dist', '.next', '.wrangler', '__pycache__', 'data', '.git'}
archive = ROOT / 'workflow-source.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name in ('modules', 'migrations', 'cloudflare', 'scripts'):
        for folder, directories, files in os.walk(ROOT / name):
            directories[:] = sorted(directory for directory in directories if directory not in excluded and not (Path(folder)/directory).is_symlink())
            for filename in sorted(files):
                file = Path(folder) / filename
                if file.is_symlink() or filename.startswith('.env') or filename in {'.dev.vars', '.DS_Store'}:
                    continue
                if file.suffix in {'.pyc', '.key', '.log', '.db', '.sqlite', '.sqlite3', '.tsbuildinfo'}:
                    continue
                tar.add(file, arcname=str(file.relative_to(ROOT)), recursive=False)
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
bootstrap = ROOT / 'prepare_source.py'
bootstrap.write_text(re.sub(r"EXPECTED = '[a-f0-9]+'", f"EXPECTED = '{digest}'", bootstrap.read_text()))
print('Complete source archive prepared; runtime data and credentials excluded')
