import { DurableObject } from 'cloudflare:workers';

const STATE = '_yifun_database_state';
const RECEIPTS = '_yifun_database_receipts';
const CHUNKS = '_yifun_database_chunks';
const LIMIT = 8 * 1024 * 1024;
const CHUNK_SIZE = 256 * 1024; // Each SQL row remains below Cloudflare's 2 MB limit.

/** Private, revisioned SQLite snapshots for the small shared test database.
 * SQL runs in the trusted application replica, including its original constraints
 * and triggers. The entire resulting state is durably committed atomically;
 * trigger-generated IDs and timestamps are never regenerated on the server.
 */
export class BusinessDatabase extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.sql = ctx.storage.sql;
    const tables = this.sql.exec("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_cf_%'").toArray();
    if (tables.some(table => ![STATE, RECEIPTS, CHUNKS].includes(table.name))) {
      throw new Error('Existing business database requires an explicit migration');
    }
    this.sql.exec(`CREATE TABLE IF NOT EXISTS ${STATE}(id INTEGER PRIMARY KEY CHECK(id=1),revision INTEGER NOT NULL,payload TEXT NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS ${RECEIPTS}(id TEXT PRIMARY KEY,revision INTEGER NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS ${CHUNKS}(ordinal INTEGER PRIMARY KEY,data BLOB NOT NULL)`);
    this.sql.exec(`INSERT OR IGNORE INTO ${STATE} VALUES(1,0,?)`, JSON.stringify({schema:[],tables:[]}));
  }
  snapshot() {
    return this.ctx.storage.transactionSync(() => {
      const state=this.sql.exec(`SELECT revision,payload FROM ${STATE} WHERE id=1`).one();
      const chunks=this.sql.exec(`SELECT data FROM ${CHUNKS} ORDER BY ordinal`).toArray();
      let text=state.payload;
      if (chunks.length) {
        const decoder=new TextDecoder('utf-8',{fatal:true});
        text=chunks.map(chunk=>decoder.decode(chunk.data,{stream:true})).join('')+decoder.decode();
      }
      return {revision:state.revision,...JSON.parse(text)};
    });
  }
  commit(payload) {
    const snapshot = payload.snapshot;
    if (!Number.isSafeInteger(payload.revision) || !/^[a-f0-9]{32}$/.test(payload.commit_id || '')
        || (!payload.unchanged && (!snapshot || !Array.isArray(snapshot.schema) || !Array.isArray(snapshot.tables)))) {
      return Response.json({error:'Invalid transaction'},{status:422});
    }
    const text = payload.unchanged ? '' : JSON.stringify(snapshot);
    if (new TextEncoder().encode(text).byteLength > LIMIT) return new Response(null,{status:413});
    const names = new Set();
    for (const item of (snapshot?.schema || [])) {
      if (!['table','index','view','trigger'].includes(item.type) || typeof item.sql !== 'string'
          || typeof item.name !== 'string' || item.name.startsWith('_yifun_') || item.name.startsWith('_cf_')) {
        return Response.json({error:'Invalid schema'},{status:422});
      }
      if (item.type === 'table') names.add(item.name);
    }
    const records = new Set();
    for (const table of (snapshot?.tables || [])) {
      if ((!names.has(table.name) && table.name !== 'sqlite_sequence') || records.has(table.name)
          || !Array.isArray(table.columns) || !table.columns.length || table.columns.some(column=>typeof column!=='string')
          || !Array.isArray(table.rows) || table.rows.some(row=>!Array.isArray(row) || row.length!==table.columns.length)) {
        return Response.json({error:'Invalid records'},{status:422});
      }
      records.add(table.name);
    }
    if ([...names].some(name=>!records.has(name))) return Response.json({error:'Missing table'},{status:422});
    try {
      const result = this.ctx.storage.transactionSync(() => {
        const receipt = this.sql.exec(`SELECT revision FROM ${RECEIPTS} WHERE id=?`,payload.commit_id).toArray()[0];
        if (receipt) return {revision:receipt.revision};
        const current = this.sql.exec(`SELECT revision FROM ${STATE} WHERE id=1`).one().revision;
        if (current !== payload.revision) throw new Error('REVISION_CONFLICT');
        const revision = current+(payload.unchanged ? 0 : 1);
        if (!payload.unchanged) {
          const bytes=new TextEncoder().encode(text);
          this.sql.exec(`DELETE FROM ${CHUNKS}`);
          for(let offset=0,ordinal=0;offset<bytes.length;offset+=CHUNK_SIZE,ordinal++) {
            this.sql.exec(`INSERT INTO ${CHUNKS} VALUES(?,?)`,ordinal,bytes.slice(offset,offset+CHUNK_SIZE).buffer);
          }
          this.sql.exec(`UPDATE ${STATE} SET revision=?,payload='' WHERE id=1`,revision);
        }
        this.sql.exec(`INSERT INTO ${RECEIPTS} VALUES(?,?)`,payload.commit_id,revision);
        this.sql.exec(`DELETE FROM ${RECEIPTS} WHERE rowid NOT IN (SELECT rowid FROM ${RECEIPTS} ORDER BY rowid DESC LIMIT 128)`);
        return {revision};
      });
      return Response.json(result);
    } catch (error) {
      return Response.json({error:'Refresh and retry'},{status:error.message==='REVISION_CONFLICT'?409:503});
    }
  }
  async fetch(request) {
    const path=new URL(request.url).pathname;
    if (request.method==='GET' && path==='/snapshot') return Response.json(this.snapshot());
    if (request.method==='POST' && path==='/commit') {
      const raw=await request.text();
      if (new TextEncoder().encode(raw).byteLength > LIMIT+1024) return new Response(null,{status:413});
      try {return this.commit(JSON.parse(raw));} catch {return new Response(null,{status:400});}
    }
    return new Response(null,{status:404});
  }
}
