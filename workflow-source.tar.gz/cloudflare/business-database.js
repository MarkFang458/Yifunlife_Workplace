import { DurableObject } from 'cloudflare:workers';

const META = '_yifun_database_revision';
const quote = value => '"' + value.replaceAll('"', '""') + '"';
function encode(value) {
  if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
    const bytes = value instanceof ArrayBuffer ? new Uint8Array(value) : new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    let text = '';
    for (const byte of bytes) text += String.fromCharCode(byte);
    return { $bytes: btoa(text) };
  }
  return value;
}
function decode(value) {
  if (value && typeof value === 'object' && Object.keys(value).length === 1 && '$bytes' in value) {
    return Uint8Array.from(atob(value.$bytes), character => character.charCodeAt(0)).buffer;
  }
  return value;
}

/** Private database service. The public router must never forward this path. */
export class BusinessDatabase extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.sql = ctx.storage.sql;
    this.sql.exec(`CREATE TABLE IF NOT EXISTS ${META}(id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL)`);
    this.sql.exec(`INSERT OR IGNORE INTO ${META} VALUES(1,0)`);
  }

  snapshot() {
    return this.ctx.storage.transactionSync(() => {
      const revision = this.sql.exec(`SELECT revision FROM ${META} WHERE id=1`).one().revision;
      const schema = this.sql.exec("SELECT type,name,sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_cf_%' AND name!=? ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 WHEN 'view' THEN 2 ELSE 3 END,name", META).toArray();
      const tables = schema.filter(item => item.type === 'table').map(item => {
        const cursor = this.sql.exec(`SELECT * FROM ${quote(item.name)}`);
        return { name: item.name, columns: cursor.columnNames, rows: Array.from(cursor.raw(), row => row.map(encode)) };
      });
      // Preserve AUTOINCREMENT history even when the highest row was deleted.
      if (this.sql.exec("SELECT 1 FROM sqlite_master WHERE name='sqlite_sequence'").toArray().length) {
        const cursor = this.sql.exec('SELECT name,seq FROM sqlite_sequence');
        tables.push({ name: 'sqlite_sequence', columns: cursor.columnNames, rows: Array.from(cursor.raw(), row => row.map(encode)) });
      }
      return { revision, schema, tables };
    });
  }

  commit(payload) {
    if (!Number.isSafeInteger(payload.revision) || !Array.isArray(payload.statements)
        || payload.statements.length < 1 || payload.statements.length > 1500) {
      return Response.json({ error: 'Invalid transaction' }, { status: 400 });
    }
    try {
      const result = this.ctx.storage.transactionSync(() => {
        const revision = this.sql.exec(`SELECT revision FROM ${META} WHERE id=1`).one().revision;
        if (revision !== payload.revision) throw new Error('REVISION_CONFLICT');
        for (const statement of payload.statements) {
          if (typeof statement.sql !== 'string' || !statement.sql.trim() || !Array.isArray(statement.params)
              || /\b_yifun_database_revision\b/i.test(statement.sql)) throw new Error('Invalid statement');
          // Fully consume each cursor within this transaction before proceeding.
          this.sql.exec(statement.sql, ...statement.params.map(decode)).toArray();
        }
        this.sql.exec(`UPDATE ${META} SET revision=revision+1 WHERE id=1`);
        return { revision: revision + 1 };
      });
      return Response.json(result);
    } catch (error) {
      const conflict = error.message === 'REVISION_CONFLICT';
      return Response.json({ error: conflict ? 'Refresh and retry' : 'Transaction rejected' }, { status: conflict ? 409 : 422 });
    }
  }

  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (request.method === 'GET' && path === '/snapshot') return Response.json(this.snapshot());
    if (request.method === 'POST' && path === '/commit') {
      const size = Number(request.headers.get('Content-Length') || 0);
      if (size > 20 * 1024 * 1024) return new Response(null, { status: 413 });
      return this.commit(await request.json());
    }
    return new Response(null, { status: 404 });
  }
}
