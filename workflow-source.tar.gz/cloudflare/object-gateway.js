// Private R2 gateway. Only the core service holds the secret; never use it in a browser.
export default {
 async fetch(request, env) {
  const supplied = request.headers.get('Authorization') || '';
  if (!env.OBJECT_TOKEN || supplied !== 'Bearer ' + env.OBJECT_TOKEN) return new Response('Unauthorized', {status:401});
  const key = decodeURIComponent(new URL(request.url).pathname.replace(/^\/objects\//,''));
  if (!new URL(request.url).pathname.startsWith('/objects/') || !/^operations\/[a-z]+\/[a-zA-Z0-9_-]+$/.test(key)) return new Response('Invalid key',{status:400});
  if (request.method === 'PUT') {
   const size = Number(request.headers.get('Content-Length'));
   if (!Number.isFinite(size) || size <= 0 || size > 5*1024*1024) return new Response('Invalid size',{status:413});
   await env.OBJECTS.put(key,request.body,{httpMetadata:{contentType:request.headers.get('Content-Type')||'application/octet-stream'}});
   return new Response(null,{status:201});
  }
  if (request.method === 'GET') {
   const object = await env.OBJECTS.get(key);
   return object ? new Response(object.body,{headers:{'Content-Type':object.httpMetadata?.contentType||'application/octet-stream','Cache-Control':'private, no-store'}}) : new Response('Not found',{status:404});
  }
  return new Response('Method not allowed',{status:405});
 }
};
