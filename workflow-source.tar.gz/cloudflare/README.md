# Cloudflare 存储边界与部署状态

完整源代码保留所有模块与页面。本仓库不包含业务数据库、附件、账号密码、会话或桥接密钥。

## 已完成的边界

- 业务关系数据统一数据库；本地使用 YIFUN_DB 外部路径。模块支持 DATABASE_BACKEND=d1 和 BUSINESS_DB 原生 D1 binding，三个模块必须绑定同一个数据库，禁止各建一套。
- 图片和附件分别通过 PRODUCT_IMAGES、FILES、ATTACHMENTS 的 R2 接口读写。数据库只保留对象 key、文件信息和归属；访问仍经过实体权限校验，不启用公开桶。
- 本地模拟对象、数据库、日志、密钥分别目录存放，并可通过环境变量放到代码目录之外。不自动搬动旧数据库和旧附件。
- 所有新增云配置均为模板，未创建云资源、未上线，不含真实数据库 ID 或密钥。

## 仍须完成才能完整部署

Python 主服务仍使用 sqlite3 事务，不可仅把模块切换到 D1 就上线：主服务必须使用相同业务数据库，并保持多语句事务、权限和并发版本检查。D1 不提供 sqlite3 直连接口，需要迁移主服务数据访问层或选择外部兼容数据库。不得把容器临时 SQLite 作为正式数据源，也不得混用本地 SQLite 与云 D1。

还需完成同域模块路由、统一登录、只读访问角色，以及全部模块的模拟数据种子。quote 与 procurement 应先按各自构建工具生成部署输出；这里的配置不是可直接部署的完整站点入口。根目录暂不提供 wrangler deploy，以避免发布不完整系统。

## 云资源规划

数据库：yifunlife-business（共享 D1）
对象桶：yifunlife-quote-files、yifunlife-procurement-files、yifunlife-aftersales-files（私有 R2）
身份与业务授权：核心服务统一处理，下载经过原有权限检查。

Cloudflare Secrets 存放 WORKSPACE_BRIDGE；不写入 Git、前端或配置模板。
部署前备份、验证模拟数据、检查所有模块写入与 CEO 汇总一致性、验证未授权访问及只读角色。

## 同域访问适配

主服务可通过 YIFUN_PUBLIC_ORIGIN 设置唯一 HTTPS 站点来源；云环境禁用本机自动登录，登录 cookie 使用 Secure，未授权请求仍被拦截。会话提供三个模块的同域地址 /modules/quote/、/modules/procurement/、/modules/aftersales/。模块 bridge 配置 PUBLIC_ORIGIN 校验提交来源。这里只完成访问层适配，网关路由和外部数据库仍须完成，不代表已部署。
