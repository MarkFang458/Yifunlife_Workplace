CREATE TABLE marketing_accounts(id TEXT PRIMARY KEY,market TEXT NOT NULL,platform TEXT NOT NULL,name TEXT NOT NULL,owner_id TEXT REFERENCES employees(id));
CREATE TABLE marketing_daily(account_id TEXT REFERENCES marketing_accounts(id),day TEXT NOT NULL,fans INTEGER NOT NULL,posts INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(account_id,day));
CREATE TABLE marketing_test_contracts(id TEXT PRIMARY KEY,account_id TEXT REFERENCES marketing_accounts(id),day TEXT NOT NULL,amount_minor INTEGER NOT NULL,currency TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active');
ALTER TABLE marketing_spends ADD COLUMN account_id TEXT REFERENCES marketing_accounts(id);
